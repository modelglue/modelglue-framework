ReadMe

This application was created by Raymond Camden (ray@camdenfamily.com) of Mindseye (www.mindseye.com). You
may use this application as you will. I ask that you link back to my blog though. 

If you find this application worthy, I have a Amazon wish list set up (www.amazon.com/o/registry/2TCL1D08EZEYE ). Gifts are always welcome. ;)

Last Updated: 1/4/06
/install/sqlserver.sql - I forgot the lines that seeded the data! Also, projectloci was using name with length 35, should have been 50
/project.cfm - handle cases with no loci or users selected 

Last Updated: 12/29/05
/project_view.cfm - fixes in filters
/components/IssueManager.cfc - bug in email that went out, would show Bug (Was Bug)

Last Updated: 12/29/05
/view.cfm - changed disabled to readonly
/projectmanager.cfc - sort getProjectsForUser
/install/sqlserver.sql - forgot to update it for attachments
/user_edit.cfm - case fix
/prefs.cfm - error when not picking a project to subscribe to

Last Updated: 12/28/05
Version 2.0
Massive update. Removal of Flash Forms. Various fixes/improvements. The only DB change is the addition of "attachment" do the db. Basically all files
need to be copied from the zip.

Last Updated: 12/2/05
project_view.cfm - fixed relatedurl in Flash Form. Wasn't loading when you clicked to edit.

There is an "unsupported" folder in the install folder. This is for DB scripts not officially supported. I've added
a Postgres SQL file supplied by David Livingston (livingston.dave@gmail.com)

Last Updated: 11/2/05
IssueManager.cfc - lowecased relatedurl in one sql block

Last Updated: 11/1/05
SQL Server install script changed issues.name to have maxlen of 255
IssueManager.cfc returns project name
rss_view.cfm calls right method, and shows project name in title of rss entry
